/********************************************************************************
** Form generated from reading UI file 'faildialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FAILDIALOG_H
#define UI_FAILDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_FailDialog
{
public:
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *timeLabel;
    QLabel *label_3;
    QPushButton *mainButton;

    void setupUi(QDialog *FailDialog)
    {
        if (FailDialog->objectName().isEmpty())
            FailDialog->setObjectName(QString::fromUtf8("FailDialog"));
        FailDialog->resize(563, 380);
        verticalLayout_3 = new QVBoxLayout(FailDialog);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(FailDialog);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(30);
        font.setBold(true);
        font.setItalic(false);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        timeLabel = new QLabel(FailDialog);
        timeLabel->setObjectName(QString::fromUtf8("timeLabel"));
        QFont font1;
        font1.setPointSize(15);
        timeLabel->setFont(font1);
        timeLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(timeLabel);

        label_3 = new QLabel(FailDialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font1);
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_3);

        verticalLayout->setStretch(0, 6);
        verticalLayout->setStretch(1, 2);
        verticalLayout->setStretch(2, 2);

        verticalLayout_2->addLayout(verticalLayout);

        mainButton = new QPushButton(FailDialog);
        mainButton->setObjectName(QString::fromUtf8("mainButton"));
        mainButton->setFont(font1);

        verticalLayout_2->addWidget(mainButton);


        verticalLayout_3->addLayout(verticalLayout_2);


        retranslateUi(FailDialog);

        QMetaObject::connectSlotsByName(FailDialog);
    } // setupUi

    void retranslateUi(QDialog *FailDialog)
    {
        FailDialog->setWindowTitle(QCoreApplication::translate("FailDialog", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("FailDialog", "\355\217\254\352\270\260\355\225\230\354\205\250\354\212\265\353\213\210\353\213\244..\360\237\230\242", nullptr));
        timeLabel->setText(QCoreApplication::translate("FailDialog", "\352\261\270\353\246\260 \354\213\234\352\260\204 : 00\353\266\20400\354\264\210", nullptr));
        label_3->setText(QCoreApplication::translate("FailDialog", "\354\202\254\354\232\251 \355\236\214\355\212\270 : 0\355\232\214", nullptr));
        mainButton->setText(QCoreApplication::translate("FailDialog", "\353\251\224\354\235\270\354\234\274\353\241\234", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FailDialog: public Ui_FailDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FAILDIALOG_H

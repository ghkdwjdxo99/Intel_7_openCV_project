/********************************************************************************
** Form generated from reading UI file 'puzzleselectdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PUZZLESELECTDIALOG_H
#define UI_PUZZLESELECTDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_PuzzleSelectDialog
{
public:
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QRadioButton *check5x5;
    QLabel *preview5x5;
    QVBoxLayout *verticalLayout_2;
    QRadioButton *check8x8;
    QLabel *preview8x8;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton;

    void setupUi(QDialog *PuzzleSelectDialog)
    {
        if (PuzzleSelectDialog->objectName().isEmpty())
            PuzzleSelectDialog->setObjectName(QString::fromUtf8("PuzzleSelectDialog"));
        PuzzleSelectDialog->resize(532, 342);
        PuzzleSelectDialog->setMaximumSize(QSize(16000000, 16000000));
        verticalLayout_4 = new QVBoxLayout(PuzzleSelectDialog);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        check5x5 = new QRadioButton(PuzzleSelectDialog);
        check5x5->setObjectName(QString::fromUtf8("check5x5"));

        verticalLayout->addWidget(check5x5);

        preview5x5 = new QLabel(PuzzleSelectDialog);
        preview5x5->setObjectName(QString::fromUtf8("preview5x5"));
        preview5x5->setMaximumSize(QSize(250, 250));
        preview5x5->setPixmap(QPixmap(QString::fromUtf8(":/images/puzzle_mask_5x5.png")));
        preview5x5->setScaledContents(true);
        preview5x5->setMargin(20);

        verticalLayout->addWidget(preview5x5);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        check8x8 = new QRadioButton(PuzzleSelectDialog);
        check8x8->setObjectName(QString::fromUtf8("check8x8"));
        check8x8->setTabletTracking(false);
        check8x8->setLayoutDirection(Qt::LeftToRight);

        verticalLayout_2->addWidget(check8x8);

        preview8x8 = new QLabel(PuzzleSelectDialog);
        preview8x8->setObjectName(QString::fromUtf8("preview8x8"));
        preview8x8->setMaximumSize(QSize(250, 250));
        preview8x8->setPixmap(QPixmap(QString::fromUtf8(":/images/puzzle_mask_8x8.png")));
        preview8x8->setScaledContents(true);
        preview8x8->setMargin(20);

        verticalLayout_2->addWidget(preview8x8);


        horizontalLayout->addLayout(verticalLayout_2);

        horizontalLayout->setStretch(0, 5);
        horizontalLayout->setStretch(1, 5);

        verticalLayout_3->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(461, 28, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButton = new QPushButton(PuzzleSelectDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout_2->addWidget(pushButton);


        verticalLayout_3->addLayout(horizontalLayout_2);

        verticalLayout_3->setStretch(0, 8);

        verticalLayout_4->addLayout(verticalLayout_3);


        retranslateUi(PuzzleSelectDialog);

        QMetaObject::connectSlotsByName(PuzzleSelectDialog);
    } // setupUi

    void retranslateUi(QDialog *PuzzleSelectDialog)
    {
        PuzzleSelectDialog->setWindowTitle(QCoreApplication::translate("PuzzleSelectDialog", "Dialog", nullptr));
        check5x5->setText(QCoreApplication::translate("PuzzleSelectDialog", "5x5", nullptr));
        preview5x5->setText(QString());
        check8x8->setText(QCoreApplication::translate("PuzzleSelectDialog", "8x8", nullptr));
        preview8x8->setText(QString());
        pushButton->setText(QCoreApplication::translate("PuzzleSelectDialog", "\354\204\240\355\203\235", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PuzzleSelectDialog: public Ui_PuzzleSelectDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PUZZLESELECTDIALOG_H

/********************************************************************************
** Form generated from reading UI file 'make_puzzle_image.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAKE_PUZZLE_IMAGE_H
#define UI_MAKE_PUZZLE_IMAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_make_puzzle_image
{
public:
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *make_puzzle_main_layout_v;
    QVBoxLayout *capture_image_layout_v;
    QGraphicsView *capture_image_graphicsView;
    QHBoxLayout *make_puzzle_btn_layout_h;
    QSpacerItem *btn_spacer_left;
    QPushButton *make_puzzle_btn;
    QSpacerItem *btn_spacer_right;

    void setupUi(QWidget *make_puzzle_image)
    {
        if (make_puzzle_image->objectName().isEmpty())
            make_puzzle_image->setObjectName(QString::fromUtf8("make_puzzle_image"));
        make_puzzle_image->resize(1024, 767);
        verticalLayout_3 = new QVBoxLayout(make_puzzle_image);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        make_puzzle_main_layout_v = new QVBoxLayout();
        make_puzzle_main_layout_v->setObjectName(QString::fromUtf8("make_puzzle_main_layout_v"));
        capture_image_layout_v = new QVBoxLayout();
        capture_image_layout_v->setObjectName(QString::fromUtf8("capture_image_layout_v"));
        capture_image_graphicsView = new QGraphicsView(make_puzzle_image);
        capture_image_graphicsView->setObjectName(QString::fromUtf8("capture_image_graphicsView"));

        capture_image_layout_v->addWidget(capture_image_graphicsView);


        make_puzzle_main_layout_v->addLayout(capture_image_layout_v);

        make_puzzle_btn_layout_h = new QHBoxLayout();
        make_puzzle_btn_layout_h->setObjectName(QString::fromUtf8("make_puzzle_btn_layout_h"));
        btn_spacer_left = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        make_puzzle_btn_layout_h->addItem(btn_spacer_left);

        make_puzzle_btn = new QPushButton(make_puzzle_image);
        make_puzzle_btn->setObjectName(QString::fromUtf8("make_puzzle_btn"));

        make_puzzle_btn_layout_h->addWidget(make_puzzle_btn);

        btn_spacer_right = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        make_puzzle_btn_layout_h->addItem(btn_spacer_right);


        make_puzzle_main_layout_v->addLayout(make_puzzle_btn_layout_h);

        make_puzzle_main_layout_v->setStretch(0, 8);
        make_puzzle_main_layout_v->setStretch(1, 2);

        verticalLayout_3->addLayout(make_puzzle_main_layout_v);


        retranslateUi(make_puzzle_image);

        QMetaObject::connectSlotsByName(make_puzzle_image);
    } // setupUi

    void retranslateUi(QWidget *make_puzzle_image)
    {
        make_puzzle_image->setWindowTitle(QCoreApplication::translate("make_puzzle_image", "Form", nullptr));
        make_puzzle_btn->setText(QCoreApplication::translate("make_puzzle_image", "\355\215\274\354\246\220 \354\240\234\354\236\221", nullptr));
    } // retranslateUi

};

namespace Ui {
    class make_puzzle_image: public Ui_make_puzzle_image {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAKE_PUZZLE_IMAGE_H

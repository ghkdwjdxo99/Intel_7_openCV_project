/********************************************************************************
** Form generated from reading UI file 'webcam_capture.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WEBCAM_CAPTURE_H
#define UI_WEBCAM_CAPTURE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_webcam_capture
{
public:
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *capture_main_layout_v;
    QVBoxLayout *video_layout_v;
    QLabel *video_label;
    QHBoxLayout *capture_layout_h;
    QSpacerItem *btn_spacer_left;
    QPushButton *capture_btn;
    QSpacerItem *btn_spacer_right;

    void setupUi(QWidget *webcam_capture)
    {
        if (webcam_capture->objectName().isEmpty())
            webcam_capture->setObjectName(QString::fromUtf8("webcam_capture"));
        webcam_capture->resize(599, 604);
        verticalLayout_4 = new QVBoxLayout(webcam_capture);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        capture_main_layout_v = new QVBoxLayout();
        capture_main_layout_v->setObjectName(QString::fromUtf8("capture_main_layout_v"));
        video_layout_v = new QVBoxLayout();
        video_layout_v->setObjectName(QString::fromUtf8("video_layout_v"));
        video_label = new QLabel(webcam_capture);
        video_label->setObjectName(QString::fromUtf8("video_label"));

        video_layout_v->addWidget(video_label);


        capture_main_layout_v->addLayout(video_layout_v);

        capture_layout_h = new QHBoxLayout();
        capture_layout_h->setObjectName(QString::fromUtf8("capture_layout_h"));
        btn_spacer_left = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        capture_layout_h->addItem(btn_spacer_left);

        capture_btn = new QPushButton(webcam_capture);
        capture_btn->setObjectName(QString::fromUtf8("capture_btn"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("images/camera.png"), QSize(), QIcon::Normal, QIcon::Off);
        capture_btn->setIcon(icon);
        capture_btn->setIconSize(QSize(100, 100));

        capture_layout_h->addWidget(capture_btn);

        btn_spacer_right = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        capture_layout_h->addItem(btn_spacer_right);


        capture_main_layout_v->addLayout(capture_layout_h);

        capture_main_layout_v->setStretch(0, 8);
        capture_main_layout_v->setStretch(1, 2);

        verticalLayout_4->addLayout(capture_main_layout_v);


        retranslateUi(webcam_capture);

        QMetaObject::connectSlotsByName(webcam_capture);
    } // setupUi

    void retranslateUi(QWidget *webcam_capture)
    {
        webcam_capture->setWindowTitle(QCoreApplication::translate("webcam_capture", "Form", nullptr));
        video_label->setText(QCoreApplication::translate("webcam_capture", "Image", nullptr));
        capture_btn->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class webcam_capture: public Ui_webcam_capture {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WEBCAM_CAPTURE_H

/********************************************************************************
** Form generated from reading UI file 'puzzle.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PUZZLE_H
#define UI_PUZZLE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_puzzle
{
public:
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_5;
    QLabel *label_4;
    QSpacerItem *horizontalSpacer_6;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *cameraButton;
    QPushButton *imageButton;

    void setupUi(QWidget *puzzle)
    {
        if (puzzle->objectName().isEmpty())
            puzzle->setObjectName(QString::fromUtf8("puzzle"));
        puzzle->resize(1166, 635);
        puzzle->setAutoFillBackground(true);
        puzzle->setStyleSheet(QString::fromUtf8("QWidget#StartPage {\n"
"  border-image: url(:/img/bg.jpg) 0 0 0 0 stretch stretch;\n"
"}"));
        horizontalLayout = new QHBoxLayout(puzzle);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_5);

        label_4 = new QLabel(puzzle);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        QFont font;
        font.setPointSize(50);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        label_4->setFont(font);

        horizontalLayout_5->addWidget(label_4);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_6);


        verticalLayout_5->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        cameraButton = new QPushButton(puzzle);
        cameraButton->setObjectName(QString::fromUtf8("cameraButton"));
        cameraButton->setStyleSheet(QString::fromUtf8(""));
        QIcon icon;
        icon.addFile(QString::fromUtf8("images/camera.png"), QSize(), QIcon::Normal, QIcon::Off);
        cameraButton->setIcon(icon);
        cameraButton->setIconSize(QSize(100, 100));
        cameraButton->setFlat(false);

        horizontalLayout_6->addWidget(cameraButton);

        imageButton = new QPushButton(puzzle);
        imageButton->setObjectName(QString::fromUtf8("imageButton"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("images/\343\205\207\343\204\264.png"), QSize(), QIcon::Normal, QIcon::Off);
        imageButton->setIcon(icon1);
        imageButton->setIconSize(QSize(50, 100));

        horizontalLayout_6->addWidget(imageButton);


        verticalLayout_5->addLayout(horizontalLayout_6);

        verticalLayout_5->setStretch(0, 8);
        verticalLayout_5->setStretch(1, 2);

        horizontalLayout->addLayout(verticalLayout_5);


        retranslateUi(puzzle);

        QMetaObject::connectSlotsByName(puzzle);
    } // setupUi

    void retranslateUi(QWidget *puzzle)
    {
        puzzle->setWindowTitle(QCoreApplication::translate("puzzle", "puzzle", nullptr));
        label_4->setText(QCoreApplication::translate("puzzle", "Puzzle Game!!", nullptr));
        cameraButton->setText(QString());
        imageButton->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class puzzle: public Ui_puzzle {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PUZZLE_H

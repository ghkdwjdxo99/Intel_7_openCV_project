#include "successdialog.h"
#include "ui_successdialog.h"

SuccessDialog::SuccessDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SuccessDialog)
{
    ui->setupUi(this);
}

SuccessDialog::~SuccessDialog()
{
    delete ui;
}

void SuccessDialog::on_mainButton_clicked()
{
    emit backToMain();  // 신호 발생
    accept();           // 다이얼로그 닫기
}

void SuccessDialog::setTime(int seconds)
{
    int minutes = seconds / 60;
    int sec = seconds % 60;
    ui->timeLabel->setText(QString("걸린 시간 : %1분 %2초")
                           .arg(minutes)
                           .arg(sec));
}

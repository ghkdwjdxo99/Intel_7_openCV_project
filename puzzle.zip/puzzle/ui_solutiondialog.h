/********************************************************************************
** Form generated from reading UI file 'solutiondialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SOLUTIONDIALOG_H
#define UI_SOLUTIONDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_SolutionDialog
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;

    void setupUi(QDialog *SolutionDialog)
    {
        if (SolutionDialog->objectName().isEmpty())
            SolutionDialog->setObjectName(QString::fromUtf8("SolutionDialog"));
        SolutionDialog->resize(400, 300);
        verticalLayout = new QVBoxLayout(SolutionDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(SolutionDialog);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);


        retranslateUi(SolutionDialog);

        QMetaObject::connectSlotsByName(SolutionDialog);
    } // setupUi

    void retranslateUi(QDialog *SolutionDialog)
    {
        SolutionDialog->setWindowTitle(QCoreApplication::translate("SolutionDialog", "Dialog", nullptr));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class SolutionDialog: public Ui_SolutionDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SOLUTIONDIALOG_H

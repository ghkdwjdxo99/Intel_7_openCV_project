/********************************************************************************
** Form generated from reading UI file 'playpage.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLAYPAGE_H
#define UI_PLAYPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "puzzleboard.h"

QT_BEGIN_NAMESPACE

class Ui_PlayPage
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_3;
    PuzzleBoard *PuzzleBoardView;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_5;
    QPushButton *HintBT;
    QPushButton *SolutionBT;
    QVBoxLayout *verticalLayout_4;
    QLabel *timerLabel;
    QPushButton *StopBT;

    void setupUi(QWidget *PlayPage)
    {
        if (PlayPage->objectName().isEmpty())
            PlayPage->setObjectName(QString::fromUtf8("PlayPage"));
        PlayPage->resize(833, 542);
        verticalLayout_2 = new QVBoxLayout(PlayPage);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        PuzzleBoardView = new PuzzleBoard(PlayPage);
        PuzzleBoardView->setObjectName(QString::fromUtf8("PuzzleBoardView"));

        verticalLayout_3->addWidget(PuzzleBoardView);


        verticalLayout->addLayout(verticalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        HintBT = new QPushButton(PlayPage);
        HintBT->setObjectName(QString::fromUtf8("HintBT"));

        verticalLayout_5->addWidget(HintBT);

        SolutionBT = new QPushButton(PlayPage);
        SolutionBT->setObjectName(QString::fromUtf8("SolutionBT"));

        verticalLayout_5->addWidget(SolutionBT);


        horizontalLayout->addLayout(verticalLayout_5);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        timerLabel = new QLabel(PlayPage);
        timerLabel->setObjectName(QString::fromUtf8("timerLabel"));
        timerLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(timerLabel);

        StopBT = new QPushButton(PlayPage);
        StopBT->setObjectName(QString::fromUtf8("StopBT"));

        verticalLayout_4->addWidget(StopBT);


        horizontalLayout->addLayout(verticalLayout_4);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(PlayPage);

        QMetaObject::connectSlotsByName(PlayPage);
    } // setupUi

    void retranslateUi(QWidget *PlayPage)
    {
        PlayPage->setWindowTitle(QCoreApplication::translate("PlayPage", "Form", nullptr));
        HintBT->setText(QCoreApplication::translate("PlayPage", "\355\236\214\355\212\270", nullptr));
        SolutionBT->setText(QCoreApplication::translate("PlayPage", "\354\233\220\353\263\270\353\263\264\352\270\260", nullptr));
        timerLabel->setText(QCoreApplication::translate("PlayPage", "00:00", nullptr));
        StopBT->setText(QCoreApplication::translate("PlayPage", "\355\217\254\352\270\260\355\225\230\352\270\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PlayPage: public Ui_PlayPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLAYPAGE_H

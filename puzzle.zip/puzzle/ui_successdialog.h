/********************************************************************************
** Form generated from reading UI file 'successdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUCCESSDIALOG_H
#define UI_SUCCESSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_SuccessDialog
{
public:
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *timeLabel;
    QLabel *label_3;
    QPushButton *mainButton;

    void setupUi(QDialog *SuccessDialog)
    {
        if (SuccessDialog->objectName().isEmpty())
            SuccessDialog->setObjectName(QString::fromUtf8("SuccessDialog"));
        SuccessDialog->resize(614, 412);
        verticalLayout_3 = new QVBoxLayout(SuccessDialog);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(SuccessDialog);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(30);
        font.setBold(true);
        font.setItalic(false);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        timeLabel = new QLabel(SuccessDialog);
        timeLabel->setObjectName(QString::fromUtf8("timeLabel"));
        QFont font1;
        font1.setPointSize(15);
        timeLabel->setFont(font1);
        timeLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(timeLabel);

        label_3 = new QLabel(SuccessDialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font1);
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_3);

        verticalLayout->setStretch(0, 6);
        verticalLayout->setStretch(1, 2);
        verticalLayout->setStretch(2, 2);

        verticalLayout_2->addLayout(verticalLayout);

        mainButton = new QPushButton(SuccessDialog);
        mainButton->setObjectName(QString::fromUtf8("mainButton"));
        mainButton->setFont(font1);

        verticalLayout_2->addWidget(mainButton);


        verticalLayout_3->addLayout(verticalLayout_2);


        retranslateUi(SuccessDialog);

        QMetaObject::connectSlotsByName(SuccessDialog);
    } // setupUi

    void retranslateUi(QDialog *SuccessDialog)
    {
        SuccessDialog->setWindowTitle(QCoreApplication::translate("SuccessDialog", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("SuccessDialog", "\354\204\261\352\263\265\355\226\210\354\212\265\353\213\210\353\213\244 \360\237\216\211", nullptr));
        timeLabel->setText(QCoreApplication::translate("SuccessDialog", "\352\261\270\353\246\260 \354\213\234\352\260\204 : 00\353\266\20400\354\264\210", nullptr));
        label_3->setText(QCoreApplication::translate("SuccessDialog", "\354\202\254\354\232\251 \355\236\214\355\212\270 : 0\355\232\214", nullptr));
        mainButton->setText(QCoreApplication::translate("SuccessDialog", "\353\251\224\354\235\270\354\234\274\353\241\234", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SuccessDialog: public Ui_SuccessDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUCCESSDIALOG_H
